package p1;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class MainClass {

	public static void main(String[] args) 
	{
    Class1 class1=new Class1();
	EntityManagerFactory fact=Persistence.createEntityManagerFactory("std1");
	EntityManager em=fact.createEntityManager();
	em.getTransaction().begin();
//************************* save ******************************************************
/*
	Class1 c=new Class1();
	c.setA(205);
	c.setB("b");
     em.persist(c);
   
	Class1 cc=new Class1();
	cc.setA(44);
    cc.setB("hello");	
    em.persist(cc);*/
//*****************************delete*************************************************
/*	Query query1=em.createQuery("from Class1");
	  query1.getResultList();
		Class1 class1=em.find(Class1.class, 204);
	em.remove(class1);
	*/
//****************************view ***************************************************
	 class1=em.find(Class1.class, 204);
//   Query query2=em.createQuery("from Class1");
//    query2.getSingleResult();
	 System.out.println(class1);
	em.getTransaction().commit();
	}

}
